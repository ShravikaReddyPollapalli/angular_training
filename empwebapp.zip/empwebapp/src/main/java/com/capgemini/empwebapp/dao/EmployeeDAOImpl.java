package com.capgemini.empwebapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import com.capgemini.empwebapp.dto.EmployeeInfoBean;

public class EmployeeDAOImpl implements EmployeeDAO {
public EmployeeInfoBean getEmployee(int empId) {
		
		return null;
	}

	public boolean addEmployee(EmployeeInfoBean employeeInfoBean) {
//		String url="jdbc:mysql://localhost:3306/emp_db?user=root&password=12345";
//		String query1="insert into emp_info values(?,?,?,?,?,?)";
		boolean isAdded = false	;
	
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			
			
            Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/emp_db?user=root&password=12345");
			
			PreparedStatement preparedStatement= connection.prepareStatement("insert into emp_info values(?,?,?,?,?,?)");
			
			
			preparedStatement.setInt(1, employeeInfoBean.getEmpId());
			preparedStatement.setString(2,employeeInfoBean.getEmpName());
			preparedStatement.setInt(3, employeeInfoBean.getAge());
		    preparedStatement.setDouble(4, employeeInfoBean.getSalary());
			preparedStatement.setString(5, employeeInfoBean.getDesignation());
			preparedStatement.setString(6, employeeInfoBean.getPassword());
			
			int result = preparedStatement.executeUpdate();
			
			if(result>0) {
	         System.out.println("inserted");
	         isAdded= true;
			}
			
			connection.close();
			

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		
		
		return isAdded;
	}

	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<EmployeeInfoBean> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeInfoBean authenticate(int empId, String password) {
		EmployeeInfoBean employeeInfoBean = getEmployee(empId);
		if(!(employeeInfoBean !=null && employeeInfoBean.getPassword().equals(password))) {
			  employeeInfoBean = null;
		}
		return null;
  }
}
