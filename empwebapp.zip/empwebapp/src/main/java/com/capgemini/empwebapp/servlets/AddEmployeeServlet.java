package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.empwebapp.dto.EmployeeInfoBean;
import com.capgemini.empwebapp.service.EmployeeService;
import com.capgemini.empwebapp.service.EmployeeServiceImpl;
@WebServlet("/addEmp")
public class AddEmployeeServlet  extends HttpServlet {
	EmployeeService empService = new EmployeeServiceImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String empIdVal = req.getParameter("empId");
		int empId = Integer.parseInt(empIdVal);
		String empName  = req.getParameter("empName");
		String ageVal = req.getParameter("age");
		int age  = Integer.parseInt(ageVal);
		String  salaryVal = req.getParameter("salary");
        double salary = Double.parseDouble(salaryVal);
        String designation  = req.getParameter("designation");
        String password = req.getParameter("password");
        
        EmployeeInfoBean employeeInfoBean = new EmployeeInfoBean();
        employeeInfoBean.setEmpId(empId);
        employeeInfoBean.setEmpName(empName);
        employeeInfoBean.setAge(age);
        employeeInfoBean.setSalary(salary);
        employeeInfoBean.setDesignation(designation);
        employeeInfoBean.setPassword(password);
		resp.setContentType("test/html");
		
		boolean isAdded = empService.addEmployee(employeeInfoBean);
		
		PrintWriter out = resp.getWriter();
		
		out.println("<html>");
		out.println("<body>");
		if(isAdded) {
			out.print("<h2 style='color: green'>Employee Added Succesfully</h2>");
			
		}else {
			out.print("<h2 style='color: red'>Unable to add succefully!!</h2>");

		}
		out.println("EmployeeId" +empIdVal);
		out.println("<br>EmployyeName= shravika");
		out.println("<br>Employee salary : 30,000");
		out.println("</body>");
		out.println("</html>");
		
		}

}
