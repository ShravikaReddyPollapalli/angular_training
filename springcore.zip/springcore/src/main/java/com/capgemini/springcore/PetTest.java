package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;
import com.capgemini.springcore.beans.Pet;

public class PetTest {
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("petConfig.xml");
	Pet myPet = context.getBean("myPet",Pet.class);
	System.out.println("pet name = " + myPet.getName());
	myPet.getAnimal().makeSound();
	myPet.getAnimal().eat();
}
}
