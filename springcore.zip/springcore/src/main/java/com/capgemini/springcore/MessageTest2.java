package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MessageBean;

public class MessageTest2 {
public static void main(String[] args) {
ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	
	//2 Get the bean from the container
	MessageBean messageBean = (MessageBean) context.getBean("messageBean"); //downcast
	
	
	
	System.out.println("Message 1 :" + messageBean.getMsg()); //welcome to string c
	
	
	MessageBean messageBean2 = context.getBean("messageBean",MessageBean.class);
	System.out.println("Message 2 :" + messageBean2.getMsg());
	//closing the container
	((AbstractApplicationContext)context).close();

}
}
