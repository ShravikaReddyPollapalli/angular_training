package com.capgemini.springcore.beans;

import com.capgemini.springcore.interfaces.Animal;

public class Dog implements Animal {

	@Override
	public void eat() {
		System.out.println("pedigree");
		
	}

	@Override
	public void makeSound() {
		System.out.println("bow bow");
		
	}

}
