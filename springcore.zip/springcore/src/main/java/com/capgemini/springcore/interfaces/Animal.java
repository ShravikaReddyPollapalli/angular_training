package com.capgemini.springcore.interfaces;

public interface Animal {
void eat();
void makeSound();
}
