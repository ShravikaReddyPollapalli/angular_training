package com.capgemini.springcore;

import java.applet.AppletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MessageBean;

public class MessageTest {
public static void main(String[] args) {
	
	
	//1.Instantiation the container
//	AppletContext context
	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	
	//2 Get the bean from the container
	MessageBean messageBean = (MessageBean) context.getBean("messageBean"); //downcast
	MessageBean messageBean2 = context.getBean("messageBean",MessageBean.class);
	
	
	System.out.println("Message 1 :" + messageBean.getMsg()); //welcome to string c
	System.out.println("Message 2 :" + messageBean2.getMsg()); // w to sc
	
	messageBean2.setMsg("hello user");
	
	System.out.println("Message 1 :" + messageBean.getMsg());// hello user
	System.out.println("Message 2 :" + messageBean2.getMsg());//hello user
	

	
//	MessageBean messageBean = new MessageBean();
//	messageBean.setMsg("hello world");
//	
//	System.out.println(messageBean.getMsg());
}
}
