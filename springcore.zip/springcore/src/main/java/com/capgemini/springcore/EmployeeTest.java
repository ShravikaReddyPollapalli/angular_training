package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;
import com.capgemini.springcore.beans.MessageBean;

public class EmployeeTest {
public static void main(String[] args) {
ApplicationContext context = new ClassPathXmlApplicationContext("employeeConfig.xml");
	EmployeeBean employeeBean = context.getBean("employee",EmployeeBean.class);
	System.out.println("employee  id :" + employeeBean.getEmpId());
	System.out.println("employee  name :" + employeeBean.getEmpName());
	System.out.println("dept id :" + employeeBean.getDepartmentBean().getDeptId());
	System.out.println("dept name :" + employeeBean.getDepartmentBean().getDeptName());
}
}
