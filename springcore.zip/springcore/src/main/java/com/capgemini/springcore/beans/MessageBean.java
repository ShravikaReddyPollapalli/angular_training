package com.capgemini.springcore.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

//import lombok.Data;

//@Data
//public class MessageBean implements InitializingBean, DisposableBean {
	public class MessageBean  {


private String msg;
public MessageBean() {
	System.out.println("its instanatitaion phase");
}
public String getMsg() {
	return msg;
}

public void setMsg(String msg) {
	this.msg = msg;
}


public void init() throws Exception {
	System.out.println("init phase");
}

public void destroy() throws Exception {
	System.out.println("Destroy phase");
}
//@Override
//public void afterPropertiesSet() throws Exception {
//	System.out.println("Init phase");
//	
//}
//
//@Override
//public void destroy() throws Exception {
//	System.out.println("destroy phase");
//	
//}


}
