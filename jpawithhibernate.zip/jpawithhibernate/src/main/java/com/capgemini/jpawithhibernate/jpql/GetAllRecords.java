package com.capgemini.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class GetAllRecords {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
	EntityManager manager = entityManagerFactory.createEntityManager();
	String jpql = "select m.id,m.mname from Movie m ";
	Query query = manager.createQuery(jpql);
	List<Object[]> recordList = query.getResultList();
	
	for(Object[] objects : recordList) {
		System.out.println("Movie Id: "+ objects[0]);
		System.out.println("Movie Name: " + objects[1]);
	}
	manager.close();
	entityManagerFactory.close();
}
}
