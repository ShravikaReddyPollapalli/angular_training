package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class InsertRecord {
public static void main(String[] args) {
	Movie movie = new Movie();
	movie.setId(101);
	movie.setMname("pk");
	movie.setRating("good");
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
	EntityManager manager = entityManagerFactory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	transaction.begin();
	manager.persist(movie);
	System.out.println("record saved");
	transaction.commit();
	manager.close();
	entityManagerFactory.close();
}//End of the main method
}//End of the Class
