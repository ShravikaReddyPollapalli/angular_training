package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class ReadRecord {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
	EntityManager manager = entityManagerFactory.createEntityManager();
	Movie record = manager.find(Movie.class, 101);
	
	System.out.println("Movie Id---"+record.getId());
	System.out.println("Movie Name---"+record.getMname());
	System.out.println("Movie Rating---"+record.getRating());
	manager.close();
	entityManagerFactory.close();
}//End Of The Main Method
}
