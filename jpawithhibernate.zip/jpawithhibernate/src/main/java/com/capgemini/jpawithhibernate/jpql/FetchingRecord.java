package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.jpawithhibernate.dto.Movie;

public class FetchingRecord {
	
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
	EntityManager manager = entityManagerFactory.createEntityManager();
	String jpql = "select m from Movie m where m.id=:mid";
//	Query query = manager.createQuery(jpql);
	TypedQuery<Movie> query = manager.createQuery(jpql, Movie.class);
	query.setParameter("mid",102);
	Movie record = (Movie) query.getSingleResult();
	System.out.println(record.getId());
	System.out.println(record.getMname());
	System.out.println(record.getRating());
}
}
