package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.jpawithhibernate.dto.Movie;

public class DynamicFetchingRecord {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
	EntityManager manager = entityManagerFactory.createEntityManager();
	String jpql = "select m from  Movie m where m.id=:mid";
	//Query query =manager.createQuery(jpql);
	TypedQuery<Movie> query = manager.createQuery(jpql,Movie.class);
	query.setParameter("mid", 102);
	Movie record=query.getSingleResult();
	System.out.println("Movie Id--"+record.getId());
	System.out.println("Movie Name---"+record.getMname());
	System.out.println("Movie Rating---"+record.getRating());
	
	manager.close();
	entityManagerFactory.close();

}
}

