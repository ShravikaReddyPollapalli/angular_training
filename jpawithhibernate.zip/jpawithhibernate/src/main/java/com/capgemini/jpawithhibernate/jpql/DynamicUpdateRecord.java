package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DynamicUpdateRecord {
	public static void main(String[] args) {
		
	
	EntityManagerFactory entityManagerFactory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null ;
	
	try {
		entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		manager = entityManagerFactory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
        String jpql="update Movie m set m.mname=:nm where m.id= :eid";
        Query query=manager.createQuery(jpql);
        query.setParameter("eid", 102);
	    query.setParameter("nm", "ABCD");
	    int record =query.executeUpdate();
	    System.out.println("Record Update--"+record);
	    transaction.commit();
	}catch(Exception e) {
	   
		e.printStackTrace();
		transaction.rollback();
	}
	manager.close();
	entityManagerFactory.close();
	}//End of the method
}
