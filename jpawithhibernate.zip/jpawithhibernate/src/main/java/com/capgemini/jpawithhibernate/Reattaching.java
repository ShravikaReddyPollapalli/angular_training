package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


import com.capgemini.jpawithhibernate.dto.Movie;

public class Reattaching {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	try
	{
		entityManagerFactory  = Persistence.createEntityManagerFactory("TestPersistence");
		manager = entityManagerFactory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		Movie record = manager.find(Movie.class, 102);
		System.out.println("----before detach---" + manager.contains(record));
		System.out.println("----");
		manager.detach(record);
		System.out.println("after detached--" + manager.contains(record));
		Movie re = manager.merge(record);
		re.setMname("kaipoche");
		transaction.commit();
	} catch (Exception e) {
		e.printStackTrace();
		transaction.rollback();
	}
}
}
