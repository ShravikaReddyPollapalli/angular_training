package com.stackroute.simplebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplebackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
