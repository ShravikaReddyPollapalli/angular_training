package com.stackroute.simplebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplebackendApplication.class, args);

//		System.out.println("Hello world!");

	}

}
