package com.stackroute.datamunger.query;

import java.util.HashMap;

//header class containing a Collection containing the headers
public class Header extends HashMap<String, Integer> {
	
}
