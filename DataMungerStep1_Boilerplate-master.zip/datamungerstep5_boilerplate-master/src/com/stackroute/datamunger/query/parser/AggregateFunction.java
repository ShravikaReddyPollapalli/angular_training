package com.stackroute.datamunger.query.parser;

/* This class is used for storing name of field, aggregate function for 
 * each aggregate function
 * */
public class AggregateFunction {

	public String getFunction() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getField() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
