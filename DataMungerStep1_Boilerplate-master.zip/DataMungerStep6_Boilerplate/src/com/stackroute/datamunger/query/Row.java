package com.stackroute.datamunger.query;

import java.util.HashMap;



//contains the row object as ColumnName/Value. Hence, HashMap is being used
public class Row extends HashMap<String, String>{
	
}
