package com.example.Favourite.model;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection="addtoyourfavourite")

public class AddFavourite {
	private String username;
	private String mealname;
	private long  fdcid;
	private String brand;
	private Nutrients nutrients[];
	public AddFavourite(String username, String mealname, long fdcid, String brand, Nutrients[] nutrients) {
		super();
		this.username = username;
		this.mealname = mealname;
		this.fdcid = fdcid;
		this.brand = brand;
		this.nutrients = nutrients;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMealname() {
		return mealname;
	}
	public void setMealname(String mealname) {
		this.mealname = mealname;
	}
	public long getFdcid() {
		return fdcid;
	}
	public void setFdcid(long fdcid) {
		this.fdcid = fdcid;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Nutrients[] getNutrients() {
		return nutrients;
	}
	public void setNutrients(Nutrients[] nutrients) {
		this.nutrients = nutrients;
	}
	
	

	
	
}
