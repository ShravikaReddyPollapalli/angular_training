package com.example.Favourite.model;


public class Nutrients {
	private float amount;
	private String derivedBy;
	private String name;
	private String unit;

	
	public Nutrients(float amount, String derivedBy, String name, String unit) {
		super();
		this.amount = amount;
		this.derivedBy = derivedBy;
		this.name = name;
		this.unit = unit;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getDerivedBy() {
		return derivedBy;
	}
	public void setDerivedBy(String derivedBy) {
		this.derivedBy = derivedBy;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	
}
