package com.example.Favourite.exception;

public class ItemAlreadyExistsException  extends Exception {

	public ItemAlreadyExistsException()
	{
		super();
	}
	
}
